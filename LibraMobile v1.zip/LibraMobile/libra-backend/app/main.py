# Ponto de entrada (onde o FastAPI nasce)
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
import bcrypt  # Vamos usar o bcrypt puro
from . import models, schemas, database
from fastapi.security import OAuth2PasswordRequestForm

app = FastAPI(title="LibraMobile API")

# Funções auxiliares para a senha (substituindo o pwd_context)
def get_password_hash(password: str):
    # Transforma a string em bytes, gera o salt e o hash
    pwd_bytes = password.encode('utf-8')
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(pwd_bytes, salt)
    return hashed_password.decode('utf-8') # Salva como string no banco

@app.post("/cadastro/aluno", status_code=201)
def cadastrar_aluno(aluno: schemas.AlunoCreate, db: Session = Depends(database.get_db)):
    try:
        # Verificar se email já existe
        if db.query(models.Usuario).filter(models.Usuario.email == aluno.email).first():
            raise HTTPException(status_code=400, detail="E-mail já cadastrado")

        # 1. Criar Usuario com o novo método de hash
        novo_usuario = models.Usuario(
            nome=aluno.nome,
            email=aluno.email,
            cpf=aluno.cpf,
            telefone=aluno.telefone,
            nascimento=aluno.nascimento,
            password_hash=get_password_hash(aluno.senha),
            cargo="aluno"
        )
        db.add(novo_usuario)
        db.flush()

        # 2. Criar Aluno
        novo_aluno = models.Aluno(
            id_usuario=novo_usuario.id,
            contato_responsavel=aluno.contato_responsavel
        )
        db.add(novo_aluno)
        db.commit()
        return {"status": "sucesso", "message": "Aluno cadastrado!"}

    except Exception as e:
        db.rollback()
        print(f"ERRO CRÍTICO NO TERMINAL: {str(e)}") # Olhe o terminal preto!
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/cadastro/professor", status_code=201)
def cadastrar_professor(prof: schemas.ProfessorCreate, db: Session = Depends(database.get_db)):
    # 1. Cria o Usuário base
    novo_usuario = models.Usuario(
        nome=prof.nome, email=prof.email, cpf=prof.cpf,
        telefone=prof.telefone, nascimento=prof.nascimento,
        password_hash=get_password_hash(prof.senha),
        cargo="professor"
    )
    db.add(novo_usuario)
    db.flush()

    # 2. Cria o registro na tabela professores
    novo_prof = models.Professor(
        id_usuario=novo_usuario.id,
        registro_profissional=prof.registro_profissional,
        certificado_prolibras=prof.certificado_prolibras
    )
    db.add(novo_prof)
    db.commit()
    return {"message": "Professor cadastrado!"}

@app.post("/cadastro/admin", status_code=201)
def cadastrar_admin(adm: schemas.AdminCreate, db: Session = Depends(database.get_db)):
    # 1. Cria o Usuário base
    novo_usuario = models.Usuario(
        nome=adm.nome, email=adm.email, cpf=adm.cpf,
        telefone=adm.telefone, nascimento=adm.nascimento,
        password_hash=get_password_hash(adm.senha),
        cargo="admin" # Ou "admin_master" dependendo da lógica que você quiser aplicar
    )
    db.add(novo_usuario)
    db.flush()

    # 2. Cria o registro na tabela admins
    novo_adm = models.Admin(
        id_usuario=novo_usuario.id,
        idadm=adm.idadm,
        setor=adm.setor
    )
    db.add(novo_adm)
    db.commit()
    return {"message": "Administrador cadastrado!"}

@app.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(database.get_db)):
    # 1. Busca o usuário pelo email (OAuth2 usa o campo 'username')
    user = db.query(models.Usuario).filter(models.Usuario.email == form_data.username).first()
    
    # 2. Verifica se o usuário existe
    if not user:
        raise HTTPException(status_code=401, detail="E-mail ou senha incorretos")

    # 3. Verifica a senha usando o bcrypt puro
    password_bytes = form_data.password.encode('utf-8')
    hash_bytes = user.password_hash.encode('utf-8')

    if not bcrypt.checkpw(password_bytes, hash_bytes):
        raise HTTPException(status_code=401, detail="E-mail ou senha incorretos")

    # 4. Retorno de sucesso (Payload do usuário)
    return {
        "access_token": "token-provisorio-libra", 
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "nome": user.nome,
            "cargo": user.cargo
        }
    }
