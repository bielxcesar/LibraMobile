# Definição das tabelas do Banco (SQLAlchemy)

from sqlalchemy import BigInteger, Column, Integer, String, ForeignKey, Date, CHAR, CheckConstraint
from .database import Base

class Usuario(Base):
    __tablename__ = "usuarios"
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    nome = Column(String(50), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    cpf = Column(CHAR(11), unique=True, nullable=False)
    telefone = Column(String(15))
    nascimento = Column(Date)
    password_hash = Column(String(255), nullable=False)
    cargo = Column(String(15))

class Aluno(Base):
    __tablename__ = "alunos"
    id_usuario = Column(Integer, ForeignKey("usuarios.id"), primary_key=True)
    contato_responsavel = Column(String(20))

class Professor(Base):
    __tablename__ = "professores"
    id_usuario = Column(Integer, ForeignKey("usuarios.id"), primary_key=True)
    registro_profissional = Column(String(20))
    certificado_prolibras = Column(String(20))

class Admin(Base):
    __tablename__ = "admins"
    id_usuario = Column(Integer, ForeignKey("usuarios.id"), primary_key=True)
    idadm = Column(String(7), nullable=False)
    setor = Column(String(50))

