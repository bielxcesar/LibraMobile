# Validação dos dados que entram/saem (Pydantic)

from pydantic import BaseModel, EmailStr
from datetime import date
from typing import Optional

class UsuarioBase(BaseModel):
    nome: str
    email: EmailStr
    cpf: str
    telefone: Optional[str] = None
    nascimento: Optional[date] = None

class AlunoCreate(UsuarioBase):
    senha: str
    contato_responsavel: Optional[str] = None

class ProfessorCreate(UsuarioBase):
    senha: str
    registro_profissional: str
    certificado_prolibras: Optional[str] = None

class AdminCreate(UsuarioBase):
    senha: str
    idadm: str
    setor: str # Lembra do limite de 12 caracteres que definimos no SQL!

class UsuarioLogin(BaseModel):
    email: EmailStr
    senha: str