# Conexão bruta com o MySQL e Sessão
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# No futuro, usaremos o .env aqui
SQLALCHEMY_DATABASE_URL = "mysql+mysqlconnector://root:@127.0.0.1:3306/LibraMobile"
engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Gerenciador de conexão
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
